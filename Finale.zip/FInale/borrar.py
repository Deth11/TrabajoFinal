import Matriz
import Cross as C


matr = []
dicc = {'Sustantivo': [('Futbol', 0), ('Remo', 0), ('Raul', 0), ('Tenis', 0)],
        'Adjetivo': [('Lindo', 0), ('Lento', 0), ('Alto', 0), ('Bueno', 0)],
        'Verbo': [('Correr', 0), ('Saltar', 0), ('Soñar', 0), ('Saludar', 0)]}

caps = True
CS = 2
CV = 1
CA = 0
mx = Matriz.matriz(dicc, matr, caps, CS, CV, CA)
print(matr)
print(mx)
C.hacer_grafico_horizontal(matr, mx, caps, dicc, CS, CV, CA)
